from setuptools import setup, find_packages

setup(
    name="sec_parsers",
    author="John Friedman",
    version="0.2",
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
    ],
)