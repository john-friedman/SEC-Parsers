# TODO Improve visualiztion

# Important colors (strong contrast, emphasis)
headers_colors_dict = {'part;': '#B8860B',
                       'item;': '#BDB76B',
                       'bullet point;': '#FAFAD2', # LightGoldenRodYellow
                       'table;': '#FAFAD2', # LightGoldenRodYellow
                       'ignore;': '#f2f2f2', # even lighter gray
                          'signatures;': '#cac635',
                       }
headers_colors_list  = [
    "#78CCAB", "#7BCDAD", "#7ECEB9", "#80CFBA", "#83D1BC",
    "#86D2BE", "#88D3C0", "#8BD4C2", "#8ED5C3", "#90D6C5",
    "#93D7C7", "#96D8C9", "#98D9CB", "#9BDACD", "#9EDCCF",
    "#A0DDD0", "#A3DED2", "#A5DFD4", "#A8E0D6", "#ABE1D7",
    "#ADE2D9", "#B0E3DB", "#B3E4DD", "#B5E5DF", "#B8E7E0",
    "#BBE8E2", "#BDE9E4", "#C0EAE6", "#C3EBE8", "#C5ECE9",
    "#C8EDEB", "#CBEEED", "#CDF0EF", "#D0F1F1", "#D3F2F2",
    "#D5F3F4", "#D8F4F5", "#DBF5F7", "#DDF6F8", "#E0F7FA"
]